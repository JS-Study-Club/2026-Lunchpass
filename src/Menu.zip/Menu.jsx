import "./Menu.css";
import homeIcon from './home.svg';
import ticket from './ticket.svg';
import mydata from './mydata.svg';
export default function Menu() {
  return (
    <div className="App">
      <div className="mycon">
        <section className="mydata">
          <div className="bottom">
            <nav className="bottom-nav">

              <img className="nav-item" src={homeIcon} />
              <img className="nav-center" src={ticket} />
              <img className="nav-item" src={mydata} />

            </nav>
          </div>
          
        </section>
      </div>
    </div>
  );
}